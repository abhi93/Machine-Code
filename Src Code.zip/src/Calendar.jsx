import React, { useState, useEffect } from 'react';
import CalendarGrid from './Components/CalendarGrid';
import EventModal from './Components/EventModal';
import Navigation from './Components/Navigation';
import { addEvent, deleteEvent, editEvent, getInitialEvents } from './Utils/eventUtils';
import './App.css';

export const CalendarApp = () => {
  const [events, setEvents] = useState([]);
  const [activeDate, setActiveDate] = useState(new Date());
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [editingEvent, setEditingEvent] = useState(null);

  useEffect(() => {
  const storedEvents = getInitialEvents();
  setEvents(storedEvents);
}, []);

  const handleAddEvent = (eventData) => {
    const newEvents = addEvent(events, eventData);
    setEvents(newEvents);
  };

  const handleEditEvent = (eventId, updatedData) => {
    const updatedEvents = editEvent(events, eventId, updatedData);
    setEvents(updatedEvents);
  };

  const handleDeleteEvent = (eventId) => {
    const filtered = deleteEvent(events, eventId);
    setEvents(filtered);
  };

  const handleDayChange = (offset) => {
    const newDate = new Date(activeDate);
    newDate.setDate(newDate.getDate() + offset);
    setActiveDate(newDate);
  };

  const handleToday = () => setActiveDate(new Date());

  return (
    <div className="calendar-app">
      <Navigation 
        currentDate={activeDate}
        onPrev={() => handleDayChange(-1)} 
        onNext={() => handleDayChange(1)} 
        onToday={handleToday} 
      />
      <CalendarGrid 
        weekStart={activeDate} 
        activeDate={activeDate} 
        selectedSlot={selectedSlot}
        events={events} 
        onSlotClick={setSelectedSlot} 
        onEventClick={setEditingEvent} 
        onDeleteEvent={handleDeleteEvent} 
      />
      {(selectedSlot || editingEvent) && (
        <EventModal 
          initialData={editingEvent || selectedSlot} 
          onClose={() => {
            setSelectedSlot(null);
            setEditingEvent(null);
          }}
          onSave={(data) => {
            editingEvent ? handleEditEvent(editingEvent.id, data) : handleAddEvent(data);
            setSelectedSlot(null);
            setEditingEvent(null);
          }}
        />
      )}
    </div>
  );
}

export default CalendarApp;