import React, { useState } from 'react';
import './EventModal.css';

const EVENT_TYPES = [
  { label: 'Task', value: 'TASK' },
  { label: 'Holiday', value: 'HOLIDAY' }
];

export default function EventModal({ initialData, onClose, onSave }) {
  const [title, setTitle] = useState(initialData?.title || '');
  const [start, setStart] = useState(new Date(initialData?.start).toISOString().slice(0, 16));
  const [end, setEnd] = useState(new Date(initialData?.end).toISOString().slice(0, 16));
  const [type, setType] = useState(initialData?.type || 'TASK');

  const handleSubmit = () => {
    if (new Date(start) >= new Date(end)) return alert("End time must be after start time");
    onSave({ ...initialData, title, start: new Date(start).getTime(), end: new Date(end).getTime(), type });
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h3>{initialData?.id ? 'Edit Event' : 'Add Event'}</h3>
        <label>
          Title:
          <input value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
        <label>
          Start:
          <input type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} />
        </label>
        <label>
          End:
          <input type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} />
        </label>
        <label>
          Type:
          <select value={type} onChange={(e) => setType(e.target.value)}>
            {EVENT_TYPES.map((opt) => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        </label>
        <div className="buttons">
          <button onClick={handleSubmit}>Save</button>
          <button onClick={onClose} className="cancel">Cancel</button>
        </div>
      </div>
    </div>
  );
}
