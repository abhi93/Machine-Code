import React from 'react';
import './Navigation.css';
import moment from 'moment';

export default function Navigation({ currentDate, onPrev, onNext, onToday }) {

  const monthYear = moment(currentDate).format('MMMM YYYY');

  return (
   <div className="nav-bar">
      <div className="nav-left"><span className='nav-date'>{monthYear}</span></div>
      <div className="nav-right">
        <button onClick={onPrev}>{'‹'}</button>
        <button onClick={onToday}>Today</button>
        <button onClick={onNext}>{'›'}</button>
      </div>
    </div>
  );
}
