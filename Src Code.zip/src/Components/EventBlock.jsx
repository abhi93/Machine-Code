import React from 'react';
import './EventBlock.css';

export default function EventBlock({ event, onClick, onDelete }) {
  const top = new Date(event.start).getHours() * 60;
  const height = (new Date(event.end) - new Date(event.start)) / (1000 * 60);

  const color = event.type === 'TASK' ? '#195957' : '#a33737';

  return (
    <div
      className={`event-block highlight`}
      style={{ top: `${top}px`, height: `${height}px`, backgroundColor: color }}
      onClick={onClick}
    >
      <span className="title">{event.title}</span>
      <span className="remove" onClick={(e) => { e.stopPropagation(); onDelete(); }}>×</span>
    </div>
  );
}
