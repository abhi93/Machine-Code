
import React from 'react';
import { getHoursInDay, getWeekDates } from '../Utils/dateUtils';
import EventBlock from './EventBlock';
import moment from 'moment';
import './CalendarGrid.css';

export default function CalendarGrid({
  weekStart,
  activeDate,
  selectedSlot,
  events,
  onSlotClick,
  onEventClick,
  onDeleteEvent
}) {
  const hours = getHoursInDay();
  const weekDates = getWeekDates(weekStart);

  return (
    <div className="calendar-grid">
      <div className="header-row">
        <div className="time-col-header"></div>
        {weekDates.map((date, idx) => (
          <div
            key={idx}
            className={`day-header ${moment(date).isSame(moment(activeDate), 'day') ? 'today' : ''}`}
          >
            {moment(date).format('ddd D')}
          </div>
        ))}
      </div>

      <div className="body">
        <div className="time-col">
          {hours.map((h) => (
            <div key={h} className="time-slot">{h}</div>
          ))}
        </div>

        {weekDates.map((date, colIdx) => (
          <div key={colIdx} className="day-col">
            {hours.map((h, rowIdx) => {
              const hourDate = new Date(date);
              hourDate.setHours(rowIdx);
              hourDate.setMinutes(0);
              hourDate.setSeconds(0);
              const isSunday = hourDate.getDay() === 0;
              const isHighlighted = selectedSlot && moment(selectedSlot.start).isSame(hourDate, 'minute');

              return (
                <div
                  key={rowIdx}
                  className={`slot ${isSunday ? 'disabled-slot' : ''} ${isHighlighted ? 'highlight' : ''}`}
                  onClick={() => {
                    if (!isSunday) {
                      onSlotClick({
                        start: new Date(hourDate),
                        end: new Date(hourDate.getTime() + 60 * 60 * 1000)
                      });
                    }
                  }}
                >
                  {isHighlighted && selectedSlot?.title && (
                    <div className="highlight-title">{selectedSlot.title}</div>
                  )}
                </div>
              );
            })}

            {events
              .filter(e => new Date(e.start).toDateString() === date.toDateString())
              .map((event, i) => (
                <EventBlock
                  key={i}
                  event={event}
                  onClick={() => onEventClick(event)}
                  onDelete={() => onDeleteEvent(event.id)}
                />
              ))}
          </div>
        ))}
      </div>
    </div>
  );
}
