
import moment from 'moment';

export function getHoursInDay() {
  const hours = [];
  for (let i = 0; i < 24; i++) {
      hours.push(moment({ hour: i }).format('h A'));
  }
  return hours;
}

export function getWeekDates(centerDate) {
  const center = moment(centerDate);
  const start = center.clone().startOf('week'); // Sunday
  return Array.from({ length: 7 }, (_, i) => start.clone().add(i, 'days').toDate());
}

export function formatDateTime(timestamp) {
  return moment(timestamp).format('YYYY-MM-DDTHH:mm');
}

export function isSameDay(date1, date2) {
  return moment(date1).isSame(moment(date2), 'day');
}
